/**
 * Project: Assignment2
 * 
 */

package a00587586.book.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.time.DateTimeException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import a00587586.book.ApplicationException;
import a00587586.book.data.Customer;
import a00587586.book.db.CustomerDao;

/**
 * @author HAINI XIAO, A00587586
 *
 */
public class CustomerReader extends Reader {

	public static final String RECORD_DELIMITER = ":";
	public static final String FIELD_DELIMITER = "\\|";

	private static final Logger LOG = LogManager.getLogger();

	/**
	 * private constructor to prevent instantiation
	 */
	private CustomerReader() {
	}

	/**
	 * Read the customer input data.
	 * 
	 * @return A collection of customers.
	 * @throws ApplicationException
	 */
	public static int read(File customerDataFile, CustomerDao dao) throws ApplicationException {
		BufferedReader customerReader = null;
		int customerCount = 0;

		LOG.debug("Reading" + customerDataFile.getAbsolutePath());
		Map<Long, Customer> customers = new HashMap<>();
		try {
			customerReader = new BufferedReader(new FileReader(customerDataFile));

			String line = null;
			line = customerReader.readLine(); // skip the header line
			while ((line = customerReader.readLine()) != null) {
				try {
					Customer customer = readCustomerString(line);
					customers.put(customer.getId(), customer);
					LOG.debug("Added " + customer.toString() + " as " + customer.getId());
				} catch (ApplicationException e) {
					LOG.error(e.getMessage());
				}
			}
		} catch (IOException e) {
			throw new ApplicationException(e.getMessage());
		} finally {
			try {
				if (customerReader != null) {
					customerReader.close();
				}
			} catch (IOException e) {
				throw new ApplicationException(e.getMessage());
			}
		}

		List<Customer> customersList = new ArrayList<>(customers.values());
		try {
			for (Customer customer : customersList) {
				dao.add(customer);
				customerCount++;
			}
		} catch (SQLException e) {
			throw new ApplicationException(e);
		}

		return customerCount;
	}

	/**
	 * Parse a CustomerForSqlServer data string into a Customer object;
	 * 
	 * @param row
	 * @throws ApplicationException
	 */
	private static Customer readCustomerString(String data) throws ApplicationException {
		String[] elements = data.split(FIELD_DELIMITER);
		if (elements.length != Customer.ATTRIBUTE_COUNT) {
			throw new ApplicationException(
					String.format("Expected %d but got %d: %s", Customer.ATTRIBUTE_COUNT, elements.length, Arrays.toString(elements)));
		}

		int index = 0;
		long id = Integer.parseInt(elements[index++]);
		String firstName = elements[index++];
		String lastName = elements[index++];
		String street = elements[index++];
		String city = elements[index++];
		String postalCode = elements[index++];
		String phone = elements[index++];
		String emailAddress = elements[index++];
		if (!Validator.validateEmail(emailAddress)) {
			throw new ApplicationException(String.format("Invalid email: %s", emailAddress));
		}
		String yyyymmdd = elements[index];
		if (!Validator.validateJoinedDate(yyyymmdd)) {
			throw new ApplicationException(String.format("Invalid joined date: %s for customer %d", yyyymmdd, id));
		}
		int year = Integer.parseInt(yyyymmdd.substring(0, 4));
		int month = Integer.parseInt(yyyymmdd.substring(4, 6));
		int day = Integer.parseInt(yyyymmdd.substring(6, 8));

		Customer customer = null;
		try {
			customer = new Customer.Builder(id, phone).setFirstName(firstName).setLastName(lastName).setStreet(street).setCity(city)
					.setPostalCode(postalCode).setEmailAddress(emailAddress).setJoinedDate(year, month, day).build();
		} catch (DateTimeException e) {
			throw new ApplicationException(e.getMessage());
		}

		return customer;
	}

	private static class Validator {

		private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		private static final String YYYYMMDD_PATTERN = "(20\\d{2})(\\d{2})(\\d{2})"; // valid for years 2000-2099

		private static Pattern emailPattern;
		private static Pattern yyyymmddPattern;

		private Validator() {
		}

		/**
		 * Validate an email string.
		 * 
		 * @param email
		 *            the email string.
		 * @return true if the email address is valid, false otherwise.
		 */
		public static boolean validateEmail(final String email) {
			if (emailPattern == null) {
				emailPattern = Pattern.compile(EMAIL_PATTERN);
			}

			Matcher matcher = emailPattern.matcher(email);
			return matcher.matches();
		}

		public static boolean validateJoinedDate(String yyyymmdd) {
			if (yyyymmddPattern == null) {
				yyyymmddPattern = Pattern.compile(YYYYMMDD_PATTERN);
			}

			Matcher matcher = yyyymmddPattern.matcher(yyyymmdd);
			return matcher.matches();
		}

	}
}
